// Passenger/cPanel compatibility wrapper
// This file loads the ESM server module
import("./dist/index.mjs").catch(function(err) {
  console.error("Startup error:", err);
  process.exit(1);
});
